<template>
  <img src="/images/logo/logo-ehub-green@2x.png" width="80" />
</template>

<script>
export default {}
</script>
