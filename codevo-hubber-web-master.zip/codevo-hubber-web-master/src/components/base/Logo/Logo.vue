<script setup></script>
<template>
  <div>
    <img
      src="/images/Logo/logo/logo-logo.png"
      srcset="
        /images/Logo/logo/logo-logo@2x.png 2x,
        /images/Logo/logo/logo-logo@3x.png 3x
      "
      class="Logologo"
    />
  </div>
</template>

<style scoped>
img.Logologo {
  width: 36px;
  height: 40px;
  margin: 0 168px 8px 170px;
  object-fit: contain;
  opacity: 0.3;
}
</style>
