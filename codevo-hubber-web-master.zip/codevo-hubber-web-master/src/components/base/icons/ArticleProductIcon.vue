<template>
  <svg
    width="30"
    height="30"
    viewBox="0 0 30 30"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M22 26v1a3 3 0 0 1-3 3h-8a3 3 0 0 1-3-3v-1h14zm0-13v12H8V13h14zM17 0a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1h-1a6 6 0 0 1 6 6H8a6 6 0 0 1 6-6h-1a1 1 0 0 1-1-1V1a1 1 0 0 1 1-1h4z"
      fill-rule="evenodd"
    />
  </svg>
</template>
