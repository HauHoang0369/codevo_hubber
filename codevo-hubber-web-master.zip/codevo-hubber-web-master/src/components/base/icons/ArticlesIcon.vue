<template>
  <svg
    width="20"
    height="20"
    viewBox="0 0 30 30"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M26.278.5A3.232 3.232 0 0 1 29.5 3.722v22.556a3.232 3.232 0 0 1-3.222 3.222H3.722A3.232 3.232 0 0 1 .5 26.278V3.722A3.232 3.232 0 0 1 3.722.5zm0 3.222H3.722v22.556h22.556V3.722zm-7.411 16.111v2.9h-11.6v-2.9h11.6zm4.833-5.8v2.9H7.267v-2.9H23.7zm0-6.766v2.9H7.267v-2.9H23.7z"
      fill="#A6ACB5"
      fill-rule="nonzero"
    />
  </svg>
</template>

<script>
export default {}
</script>
