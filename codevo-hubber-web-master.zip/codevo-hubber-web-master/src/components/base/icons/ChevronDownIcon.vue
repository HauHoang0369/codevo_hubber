<template>
  <svg
    width="20"
    height="21"
    viewBox="0 0 20 21"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M9.43 14.465a.91.91 0 0 0 1.067.054l.074-.054 9.09-7.333a.91.91 0 0 0-1.066-1.47l-.075.055L10 12.59 1.48 5.717a.91.91 0 0 0-1.216.067l-.062.07A.91.91 0 0 0 .269 7.07l.07.062 9.09 7.333z"
      fill-rule="evenodd"
    />
  </svg>
</template>
