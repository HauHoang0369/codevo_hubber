<template>
  <svg
    width="22"
    height="22"
    viewBox="0 0 22 22"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M6.34 10.404a.949.949 0 0 0-.055 1.115l.056.077 7.651 9.486a.949.949 0 0 0 1.534-1.113l-.057-.078L8.297 11l7.172-8.89A.949.949 0 0 0 15.4.84l-.073-.064a.949.949 0 0 0-1.269.07l-.065.072-7.651 9.486z"
      fill="#A6ACB5"
      fill-rule="evenodd"
    />
  </svg>
</template>

<script>
export default {}
</script>
