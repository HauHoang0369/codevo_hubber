<template>
  <svg
    width="22"
    height="22"
    viewBox="0 0 22 22"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M15.66 10.404c.26.323.278.774.055 1.115l-.056.077-7.651 9.486a.949.949 0 0 1-1.534-1.113l.057-.078L13.703 11 6.53 2.11A.949.949 0 0 1 6.6.84l.073-.064a.949.949 0 0 1 1.269.07l.065.072 7.651 9.486z"
      fill="#A6ACB5"
      fill-rule="evenodd"
    />
  </svg>
</template>

<script>
export default {}
</script>
