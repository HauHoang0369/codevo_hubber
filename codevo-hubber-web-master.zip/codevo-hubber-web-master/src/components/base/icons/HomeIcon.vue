<template>
  <svg width="20" viewBox="0 0 30 30" xmlns="http://www.w3.org/2000/svg">
    <path
      d="m15.638.692.092.086L28.42 14.316a1 1 0 0 1-.613 1.677l-.116.007h-2.693L25 27a3 3 0 0 1-3 3h-3v-8a4 4 0 1 0-8 0v8H8a3 3 0 0 1-3-3V16H2.307a1 1 0 0 1-.586-.19l-.098-.08a1 1 0 0 1-.125-1.317l.08-.097L14.27.778a1 1 0 0 1 1.368-.086z"
      fill="#A6ACB5"
      fill-rule="evenodd"
    />
  </svg>
</template>

<script>
export default {}
</script>
