<template>
  <svg width="20" viewBox="0 0 30 30" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M3.5 2h16a1.5 1.5 0 0 1 0 3h-16a1.5 1.5 0 0 1 0-3zm0 12h24a1.5 1.5 0 0 1 0 3h-24a1.5 1.5 0 0 1 0-3zm0 12h16a1.5 1.5 0 0 1 0 3h-16a1.5 1.5 0 0 1 0-3z"
      fill="#A6ACB5"
      fill-rule="evenodd"
    />
  </svg>
</template>

<script>
export default {}
</script>
