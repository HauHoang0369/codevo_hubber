<template>
  <svg
    class="ml-20"
    width="31"
    height="30"
    viewBox="0 0 31 30"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M29.405 12.954c.394.394.4 1.025 0 1.425L19.163 24.62c-.393.393-.712.264-.712-.296V18.5C10.119 18.5 4.284 21.167.118 27 1.784 18.667 6.784 10.333 18.45 8.667V2.998c0-.551.312-.686.712-.286l10.242 10.242z"
      fill-rule="evenodd"
      fill="currentColor"
    />
  </svg>
</template>
