<script>
export default {
  name: 'SolutionIcon',

  props: {
    pathColor: {
      type: String,
      default: '',
    },
    svgClass: {
      type: String,
      default: ''
    }
  }
}
</script>
<template>
  <svg
    :class="{ svgClass }"
    width="30"
    height="30"
    viewBox="0 0 30 30"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M17 27a1 1 0 0 1 0 2h-4a1 1 0 0 1 0-2h4zm2-3a1 1 0 0 1 0 2h-8a1 1 0 0 1 0-2h8zM14.98 0c9.844.003 11.248 8.678 9.222 12.524-1.773 3.37-3.886 5.835-3.886 7.774 0 2.606-1.707 2.702-1.959 2.702h-6.702c-.116-.003-1.995-.083-1.995-2.702 0-1.939-2.08-4.404-3.855-7.774C3.78 8.678 5.135.004 14.98 0zm2.81 2.302c-1.622.59-2.171 3.172-1.227 5.767.945 2.595 3.025 4.22 4.647 3.63 1.622-.59 2.171-3.173 1.227-5.768-.945-2.595-3.025-4.22-4.647-3.63z"
      :fill="pathColor || '#E2E4E7'"
      fill-rule="evenodd"
    />
  </svg>
</template>
