<script>
export default {
  name: 'SystemBackIcon'

  // props: {
  //   pathColor: {
  //     type: String,
  //     default: ''
  //   }
  // }
}
</script>
<template>

  <svg width="32" height="31" viewBox="0 0 32 31" xmlns="http://www.w3.org/2000/svg">
    <path
      d="m11.93 2.29-.09.097L1.21 15.215a1.256 1.256 0 0 0-.077 1.507l.078.104 10.63 12.828a1.342 1.342 0 0 0 1.853.193 1.26 1.26 0 0 0 .277-1.698l-.08-.106L5.199 17.55h24.035a1.5 1.5 0 0 0 1.5-1.5v-.061a1.5 1.5 0 0 0-1.5-1.5H5.197l8.695-10.492a1.258 1.258 0 0 0-.098-1.716l-.1-.088a1.345 1.345 0 0 0-1.764.095z"
      fill="currentColor" fill-rule="evenodd" />
  </svg>

</template>

