class SocialWallTestData {
  constructor() {}

  // overrides base service method
}

export default SocialWallTestData
