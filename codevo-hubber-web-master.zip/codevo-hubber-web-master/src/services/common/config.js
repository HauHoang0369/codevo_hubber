export const PageableSettings = {
  page: 0,
  size: 10,
  sort: ['asc'],
}
