<template>
  <v-container class=""></v-container>
</template>

<script>
/**
 * This view is for testing
 */

// Components
// import CustomButton from './buttons/CustomButton.vue'
import Login from './Auth/Login/Login.vue'
import Register from './Auth/Register/Register.vue'

export default {
  components: {
    Login,
    Register,
  },
  data: () => ({}),
}
</script>
