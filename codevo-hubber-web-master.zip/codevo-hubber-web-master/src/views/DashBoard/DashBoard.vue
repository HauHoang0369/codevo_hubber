<template>
  <div>Dashboard</div>
</template>

<script>
// Components

export default {
  components: {},
  data: () => ({}),
}
</script>

<style type="text/css"></style>
